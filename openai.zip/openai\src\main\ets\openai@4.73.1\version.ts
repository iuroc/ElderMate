export const VERSION = '4.73.1'; // x-release-please-version
