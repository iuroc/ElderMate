// File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

export interface ErrorObject {
    code: string | null;

    message: string;

    param: string | null;

    type: string;
}

export interface FunctionDefinition {
    /**
     * The name of the function to be called. Must be a-z, A-Z, 0-9, or contain
     * underscores and dashes, with a maximum length of 64.
     */
    name: string;

    /**
     * A description of what the function does, used by the model to choose when and
     * how to call the function.
     */
    description?: string;

    /**
     * The parameters the functions accepts, described as a JSON Schema object. See the
     * [guide](https://platform.openai.com/docs/guides/function-calling) for examples,
     * and the
     * [JSON Schema reference](https://json-schema.org/understanding-json-schema/) for
     * documentation about the format.
     *
     * Omitting `parameters` defines a function with an empty parameter list.
     */
    parameters?: FunctionParameters;

    /**
     * Whether to enable strict schema adherence when generating the function call. If
     * set to true, the model will follow the exact schema defined in the `parameters`
     * field. Only a subset of JSON Schema is supported when `strict` is `true`. Learn
     * more about Structured Outputs in the
     * [function calling guide](docs/guides/function-calling).
     */
    strict?: boolean | null;
}

/**
 * The parameters the functions accepts, described as a JSON Schema object. See the
 * [guide](https://platform.openai.com/docs/guides/function-calling) for examples,
 * and the
 * [JSON Schema reference](https://json-schema.org/understanding-json-schema/) for
 * documentation about the format.
 *
 * Omitting `parameters` defines a function with an empty parameter list.
 */
export type FunctionParameters = Record<string, unknown>;

export interface ResponseFormatJSONObject {
    /**
     * The type of response format being defined: `json_object`
     */
    type: 'json_object';
}

export interface ResponseFormatJSONSchema {
    json_schema: ResponseFormatJSONSchema.JSONSchema;

    /**
     * The type of response format being defined: `json_schema`
     */
    type: 'json_schema';
}

export namespace ResponseFormatJSONSchema {
    export interface JSONSchema {
        /**
         * The name of the response format. Must be a-z, A-Z, 0-9, or contain underscores
         * and dashes, with a maximum length of 64.
         */
        name: string;

        /**
         * A description of what the response format is for, used by the model to determine
         * how to respond in the format.
         */
        description?: string;

        /**
         * The schema for the response format, described as a JSON Schema object.
         */
        schema?: Record<string, unknown>;

        /**
         * Whether to enable strict schema adherence when generating the output. If set to
         * true, the model will always follow the exact schema defined in the `schema`
         * field. Only a subset of JSON Schema is supported when `strict` is `true`. To
         * learn more, read the
         * [Structured Outputs guide](https://platform.openai.com/docs/guides/structured-outputs).
         */
        strict?: boolean | null;
    }
}

export interface ResponseFormatText {
    /**
     * The type of response format being defined: `text`
     */
    type: 'text';
}
