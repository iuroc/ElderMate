/**
 * Disclaimer: modules in _shims aren't intended to be imported by SDK users.
 */
/**
 * Types will get added to this namespace when you import one of the following:
 *
 *   import 'openai/shims/node'
 *   import 'openai/shims/web'
 *
 * Importing more than one will cause type and runtime errors.
 */
export namespace manual {}
