import { ChatCompletionMessageParam } from './openai@4.73.1/resources/chat/completions'

export type ChatCompletionMessageParam_role = ChatCompletionMessageParam['role']